from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
app = Flask(__name__)
app.secret_key = "qaverse-secret-key"

# MySQL configuration
app.config["MYSQL_HOST"] = "localhost"
app.config["MYSQL_USER"] = "root"
app.config["MYSQL_PASSWORD"] = ""
app.config["MYSQL_DB"] = "qaverse_db"

# Initialize MySQL
mysql = MySQL(app)


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():

    if request.method == "POST":

        full_name = request.form["full_name"]
        email = request.form["email"]
        password = request.form["password"]
        confirm_password = request.form["confirm_password"]

        # Check whether passwords match
        if password != confirm_password:
            return "Passwords do not match"

        # Hash password
        password_hash = generate_password_hash(password)

        # Get database cursor
        cursor = mysql.connection.cursor()

        # Insert student into users table
        cursor.execute("""
            INSERT INTO users
            (role_id, full_name, email, password_hash)
            VALUES (%s, %s, %s, %s)
        """, (2, full_name, email, password_hash))

        # Save changes
        mysql.connection.commit()

        # Close cursor
        cursor.close()

        return "Registration successful!"

    return render_template("register.html")
@app.route("/login", methods=["GET", "POST"])
def login():

    if request.method == "POST":

        email = request.form["email"]
        password = request.form["password"]

        cursor = mysql.connection.cursor()

        cursor.execute(
            "SELECT user_id, full_name, password_hash, role_id FROM users WHERE email = %s",
            (email,)
        )

        user = cursor.fetchone()

        cursor.close()

        # Check whether user exists
        if user is None:
            return "Invalid email or password"

        user_id, full_name, password_hash, role_id = user

        # Check password
        if not check_password_hash(password_hash, password):
            return "Invalid email or password"

        # Create session
        session["user_id"] = user_id
        session["full_name"] = full_name
        session["role_id"] = role_id

        return redirect(url_for("dashboard"))

    return render_template("login.html")
@app.route("/dashboard")
def dashboard():

    if "user_id" not in session:
        return redirect(url_for("login"))

    user_id = session["user_id"]

    cursor = mysql.connection.cursor()

    # Get total number of lessons
    cursor.execute("""
        SELECT COUNT(*)
        FROM lessons
    """)

    total_lessons = cursor.fetchone()[0]

    # Get completed lessons for current user
    cursor.execute("""
        SELECT COUNT(*)
        FROM user_progress
        WHERE user_id = %s
        AND completed = TRUE
    """, (user_id,))

    completed_lessons = cursor.fetchone()[0]

    cursor.close()

    # Calculate progress percentage
    if total_lessons > 0:
        progress_percentage = round(
            (completed_lessons / total_lessons) * 100
        )
    else:
        progress_percentage = 0

    return render_template(
        "dashboard.html",
        total_lessons=total_lessons,
        completed_lessons=completed_lessons,
        progress_percentage=progress_percentage
    )
@app.route("/logout")
def logout():

    session.clear()

    return redirect(url_for("login"))
@app.route("/learn")
def learn():

    cursor = mysql.connection.cursor()

    cursor.execute("SELECT * FROM courses")

    courses = cursor.fetchall()

    cursor.close()

    return render_template("courses.html", courses=courses)
@app.route("/learn/<int:course_id>")
def topics(course_id):

    cursor = mysql.connection.cursor()

    # Get course information
    cursor.execute(
        "SELECT course_name FROM courses WHERE course_id = %s",
        (course_id,)
    )

    course = cursor.fetchone()

    if course is None:
        cursor.close()
        return "Course not found", 404

    # Get topics for this course
    cursor.execute("""
        SELECT topic_id, topic_name, description
        FROM topics
        WHERE course_id = %s
        ORDER BY topic_order
    """, (course_id,))

    topics = cursor.fetchall()

    cursor.close()

    return render_template(
        "topics.html",
        course_name=course[0],
        topics=topics
    )
@app.route("/learn/topic/<int:topic_id>")
def lessons(topic_id):

    cursor = mysql.connection.cursor()

    # Get topic name
    cursor.execute(
        "SELECT topic_name FROM topics WHERE topic_id = %s",
        (topic_id,)
    )

    topic = cursor.fetchone()

    if topic is None:
        cursor.close()
        return "Topic not found", 404

    # Get lessons for this topic
    cursor.execute("""
        SELECT lesson_id, title, content
        FROM lessons
        WHERE topic_id = %s
        ORDER BY lesson_order
    """, (topic_id,))

    lessons = cursor.fetchall()

    cursor.close()

    return render_template(
        "lessons.html",
        topic_name=topic[0],
        lessons=lessons
    )
@app.route("/learn/lesson/<int:lesson_id>")
def lesson_detail(lesson_id):

    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    # Get current lesson
    cursor.execute("""
        SELECT lesson_id, title, content, topic_id, lesson_order
        FROM lessons
        WHERE lesson_id = %s
    """, (lesson_id,))

    lesson = cursor.fetchone()

    if lesson is None:
        cursor.close()
        return "Lesson not found", 404

    topic_id = lesson[3]
    current_order = lesson[4]

    # Check completion
    cursor.execute("""
        SELECT progress_id
        FROM user_progress
        WHERE user_id = %s AND lesson_id = %s
        AND completed = TRUE
    """, (session["user_id"], lesson_id))

    progress = cursor.fetchone()

    # Previous lesson
    cursor.execute("""
        SELECT lesson_id
        FROM lessons
        WHERE topic_id = %s
        AND lesson_order < %s
        ORDER BY lesson_order DESC
        LIMIT 1
    """, (topic_id, current_order))

    previous_lesson = cursor.fetchone()

    # Next lesson
    cursor.execute("""
        SELECT lesson_id
        FROM lessons
        WHERE topic_id = %s
        AND lesson_order > %s
        ORDER BY lesson_order ASC
        LIMIT 1
    """, (topic_id, current_order))

    next_lesson = cursor.fetchone()

    cursor.close()

    completed = progress is not None

    return render_template(
        "lesson_detail.html",
        lesson=lesson,
        completed=completed,
        previous_lesson=previous_lesson,
        next_lesson=next_lesson
    )
@app.route("/practice/quiz")
def quiz():
    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT quiz_id, quiz_title, description
        FROM quizzes
        ORDER BY quiz_id
    """)

    quizzes = cursor.fetchall()

    cursor.close()

    return render_template("quiz.html", quizzes=quizzes)
@app.route("/practice/quiz/<int:quiz_id>")
def start_quiz(quiz_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    # Get quiz details
    cursor.execute("""
        SELECT quiz_id, quiz_title, description
        FROM quizzes
        WHERE quiz_id = %s
    """, (quiz_id,))

    quiz = cursor.fetchone()

    if quiz is None:
        cursor.close()
        return "Quiz not found", 404

    # Get questions
    cursor.execute("""
        SELECT question_id, question_text,
               option_a, option_b, option_c, option_d
        FROM quiz_questions
        WHERE quiz_id = %s
        ORDER BY question_id
    """, (quiz_id,))

    questions = cursor.fetchall()

    cursor.close()

    return render_template(
        "quiz_questions.html",
        quiz=quiz,
        questions=questions
    )
@app.route("/practice/quiz/<int:quiz_id>/submit", methods=["POST"])
def submit_quiz(quiz_id):
    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    # Get all questions and correct answers
    cursor.execute("""
        SELECT question_id, correct_answer
        FROM quiz_questions
        WHERE quiz_id = %s
        ORDER BY question_id
    """, (quiz_id,))

    questions = cursor.fetchall()

    score = 0
    total_questions = len(questions)

    # Check each answer
    for question in questions:
        question_id = question[0]
        correct_answer = question[1]

        selected_answer = request.form.get(
            f"question_{question_id}"
        )

        if selected_answer == correct_answer:
            score += 1

    # Save quiz attempt
    cursor.execute("""
        INSERT INTO quiz_attempts
        (user_id, quiz_id, score, total_questions)
        VALUES (%s, %s, %s, %s)
    """, (
        session["user_id"],
        quiz_id,
        score,
        total_questions
    ))

    mysql.connection.commit()
    cursor.close()

    return render_template(
        "quiz_result.html",
        score=score,
        total_questions=total_questions
    )

@app.route("/practice/history")
def quiz_history():
    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT
            q.quiz_title,
            qa.score,
            qa.total_questions,
            qa.attempted_at
        FROM quiz_attempts qa
        JOIN quizzes q
            ON qa.quiz_id = q.quiz_id
        WHERE qa.user_id = %s
        ORDER BY qa.attempted_at DESC
    """, (session["user_id"],))

    attempts = cursor.fetchall()

    cursor.close()

    return render_template(
        "quiz_history.html",
        attempts=attempts
    )
@app.route("/practice/test-cases")
def test_case_practice():
    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT scenario_id, title, description, expected_behavior
        FROM test_case_scenarios
        ORDER BY scenario_id
    """)

    scenarios = cursor.fetchall()

    cursor.close()

    return render_template(
        "test_case_practice.html",
        scenarios=scenarios
    )
@app.route("/practice/test-cases/<int:scenario_id>/start", methods=["GET", "POST"])
def start_test_case_practice(scenario_id):

    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT scenario_id, title, description, expected_behavior
        FROM test_case_scenarios
        WHERE scenario_id = %s
    """, (scenario_id,))

    scenario = cursor.fetchone()
    cursor.close()

    if not scenario:
        return "Scenario not found", 404

    if request.method == "POST":

        test_case_title = request.form["test_case_title"]
        test_steps = request.form["test_steps"]
        test_data = request.form["test_data"]
        expected_result = request.form["expected_result"]

        cursor = mysql.connection.cursor()

        cursor.execute("""
            INSERT INTO user_test_cases
            (user_id, scenario_id, test_case_title,
             test_steps, test_data, expected_result)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (
            session["user_id"],
            scenario_id,
            test_case_title,
            test_steps,
            test_data,
            expected_result
        ))

        mysql.connection.commit()
        cursor.close()

        return "Test case submitted successfully!"

    return render_template(
        "write_test_case.html",
        scenario=scenario
    )
@app.route("/learn/lesson/<int:lesson_id>/complete", methods=["POST"])
def complete_lesson(lesson_id):

    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        INSERT INTO user_progress
        (user_id, lesson_id, completed, completed_at)
        VALUES (%s, %s, TRUE, NOW())
        ON DUPLICATE KEY UPDATE
        completed = TRUE,
        completed_at = NOW()
    """, (session["user_id"], lesson_id))

    mysql.connection.commit()

    cursor.close()

    return redirect(url_for("lesson_detail", lesson_id=lesson_id))
@app.route("/practice/my-test-cases")
def my_test_cases():
    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT
            utc.test_case_id,
            ts.title,
            utc.test_case_title,
            utc.test_steps,
            utc.test_data,
            utc.expected_result,
            utc.created_at
        FROM user_test_cases utc
        JOIN test_case_scenarios ts
            ON utc.scenario_id = ts.scenario_id
        WHERE utc.user_id = %s
        ORDER BY utc.created_at DESC
    """, (session["user_id"],))

    test_cases = cursor.fetchall()
    cursor.close()

    return render_template(
        "my_test_cases.html",
        test_cases=test_cases
    )  



def evaluate_test_case(test_case_title, test_steps, test_data, expected_result):
    score = 0
    feedback = []

    if test_case_title and test_case_title.strip():
        score += 25
    else:
        feedback.append("Add a clear test case title.")

    if test_steps and len(test_steps.strip()) >= 10:
        score += 25
    else:
        feedback.append("Provide clear and detailed test steps.")

    if test_data and test_data.strip():
        score += 25
    else:
        feedback.append("Include test data, such as valid or invalid login details.")

    if expected_result and len(expected_result.strip()) >= 10:
        score += 25
    else:
        feedback.append("Describe the expected result clearly.")

    if not feedback:
        feedback.append("Good job! All basic test case quality checks passed.")

    return score, feedback

@app.route("/practice/evaluate-test-case/<int:test_case_id>")
def evaluate_saved_test_case(test_case_id):

    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT test_case_id, test_case_title, test_steps,
               test_data, expected_result
        FROM user_test_cases
        WHERE test_case_id = %s AND user_id = %s
    """, (test_case_id, session["user_id"]))

    test_case = cursor.fetchone()
    cursor.close()

    if not test_case:
        return "Test case not found", 404

    # Evaluate the submitted test case
    score, feedback = evaluate_test_case(
        test_case[1],
        test_case[2],
        test_case[3] or "",
        test_case[4]
    )

    # Convert feedback list into text for the database
    feedback_text = "\n".join(feedback)

    # Save the evaluation result
    cursor = mysql.connection.cursor()

    cursor.execute("""
        INSERT INTO evaluation_history
        (user_id, test_case_id, score, feedback)
        VALUES (%s, %s, %s, %s)
    """, (
        session["user_id"],
        test_case_id,
        score,
        feedback_text
    ))

    mysql.connection.commit()
    cursor.close()

    # Display the evaluation result
    return render_template(
        "evaluate_test_case.html",
        test_case=test_case,
        score=score,
        feedback=feedback
    )

@app.route("/practice/evaluation-history")
def evaluation_history():

    if "user_id" not in session:
        return redirect(url_for("login"))

    cursor = mysql.connection.cursor()

    cursor.execute("""
        SELECT
            eh.evaluation_id,
            utc.test_case_title,
            eh.score,
            eh.feedback,
            eh.evaluated_at
        FROM evaluation_history eh
        JOIN user_test_cases utc
            ON eh.test_case_id = utc.test_case_id
        WHERE eh.user_id = %s
        ORDER BY eh.evaluated_at DESC
    """, (session["user_id"],))

    evaluations = cursor.fetchall()
    cursor.close()

    return render_template(
        "evaluation_history.html",
        evaluations=evaluations
    )


if __name__ == "__main__":
    app.run(debug=True)
